package com.rgcattlefeed.app

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var verificationId: String? = null
    private lateinit var phoneInput: EditText
    private lateinit var otpInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "RG Cattle Feed"
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "RG Cattle Feed"
            textSize = 26f
        })
        layout.addView(TextView(this).apply {
            text = "मालिक और ग्राहक के लिए बिज़नेस ऐप"
            textSize = 16f
        })
        phoneInput = EditText(this).apply {
            hint = "मोबाइल नंबर, देश कोड सहित (+91...)"
            inputType = 3
        }
        layout.addView(phoneInput)
        layout.addView(Button(this).apply {
            text = "OTP भेजें"
            setOnClickListener { sendOtp() }
        })
        otpInput = EditText(this).apply {
            hint = "SMS से मिला OTP"
            inputType = 2
        }
        layout.addView(otpInput)
        layout.addView(Button(this).apply {
            text = "OTP सत्यापित करें"
            setOnClickListener { verifyOtp() }
        })
        status = TextView(this).apply {
            text = "पहले Firebase सेटअप पूरा करें।"
            textSize = 14f
        }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "आगे: स्टॉक • बिलिंग • कैश/UPI/बैंक/उधारी • ग्राहक ऑर्डर"
            textSize = 14f
        })
        setContentView(layout)
    }

    private fun sendOtp() {
        val phone = phoneInput.text.toString().trim()
        if (!phone.startsWith("+") || phone.length < 10) {
            phoneInput.error = "देश कोड सहित नंबर लिखें, जैसे +91..."
            return
        }
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    auth.signInWithCredential(credential).addOnCompleteListener { task ->
                        status.text = if (task.isSuccessful) "मोबाइल सत्यापित हुआ।" else "सत्यापन विफल।"
                    }
                }
                override fun onVerificationFailed(e: FirebaseException) {
                    status.text = "OTP नहीं भेजा जा सका: ${e.localizedMessage ?: "कृपया सेटअप जाँचें"}"
                }
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    verificationId = id
                    status.text = "OTP भेजा गया। SMS में आया कोड दर्ज करें।"
                }
            })
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun verifyOtp() {
        val id = verificationId
        val code = otpInput.text.toString().trim()
        if (id.isNullOrBlank()) {
            status.text = "पहले OTP भेजें।"
            return
        }
        if (code.length < 6) {
            otpInput.error = "6 अंकों का OTP दर्ज करें"
            return
        }
        val credential = PhoneAuthProvider.getCredential(id, code)
        auth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                status.text = "लॉगिन सफल। अगला चरण: भूमिका और डेटाबेस जोड़ना।"
                Toast.makeText(this, "लॉगिन सफल", Toast.LENGTH_SHORT).show()
            } else {
                status.text = "OTP सत्यापित नहीं हुआ। कोड जाँचें।"
            }
        }
    }
}

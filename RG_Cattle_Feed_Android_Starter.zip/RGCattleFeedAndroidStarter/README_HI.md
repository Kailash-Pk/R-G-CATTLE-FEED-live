# RG Cattle Feed Android Starter

यह Android Studio के लिए शुरुआती source project है, तैयार/हस्ताक्षरित APK नहीं।

## महत्वपूर्ण
- अभी demo UI और Firebase Phone OTP flow का starter है।
- OTP के लिए Firebase project बनाना, Android app register करना, SHA-256/SHA-1 जोड़ना और `google-services.json` को `app/` में रखना जरूरी है।
- Firebase Console में Authentication > Sign-in method > Phone सक्षम करें।
- असली ग्राहक/बिक्री डेटा इस्तेमाल करने से पहले Firestore rules, role-based admin access, backups, privacy notice और testing पूरा करें।
- इस starter में ऑनलाइन UPI payment processing नहीं है; सिर्फ payment mode/record के लिए जगह बनाई गई है।

## Android Studio में चलाने के चरण
1. Android Studio में `Open` चुनें और इस folder को खोलें।
2. Android SDK 35 और JDK 17 उपलब्ध रखें।
3. Firebase Console में project और Android app बनाएं। Package name: `com.rgcattlefeed.app`
4. Firebase से `google-services.json` डाउनलोड कर `app/google-services.json` में रखें।
5. Firebase Authentication में Phone sign-in चालू करें और Firebase Console में test phone number configure करके पहले परीक्षण करें।
6. Gradle sync करें और emulator/अपने Android फोन पर Run करें।

## सिर्फ मोबाइल होने पर
Android Studio आम तौर पर कंप्यूटर/लैपटॉप पर चलता है। यह ZIP source files हैं; इन्हें सीधे फोन पर APK की तरह install नहीं किया जा सकता। केवल फोन से आगे बढ़ने के लिए किसी भरोसेमंद cloud build service/Android developer की मदद चाहिए। Firebase credentials, OTP या signing key किसी अनजान व्यक्ति से साझा न करें।

## अभी शामिल
- Kotlin Android starter screen
- Phone number और OTP input flow का Firebase starter
- Manifest, Gradle configuration
- Firestore security rules का सुरक्षित deny-by-default नमूना
